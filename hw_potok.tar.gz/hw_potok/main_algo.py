import typing as tp

import algo
import network_graph
import visualization
from network_graph import ResidualNetwork, NodeId, EdgeId


class MaximumFlowFinder:
    @staticmethod
    def find(network: network_graph.SimpleNetwork) -> None:
        r_network = network_graph.ResidualNetwork()
        r_network.setup(network)

        while True:
            bfs_edges = algo.BFS.find_minimal_way(r_network)

            if not bfs_edges:
                break

            inc = MaximumFlowFinder.__find_min_flow_in_increasing_way(r_network, bfs_edges)

            for edge_id in bfs_edges:
                if r_network.edge_exist_q(edge_id, True):
                    edge_id = network_graph.reverse_edge(edge_id)
                    old_flow = network.get_edge_flow(edge_id, False)
                    network.set_edge_flow(edge_id, old_flow - inc)
                else:
                    old_flow = network.get_edge_flow(edge_id, False)
                    network.set_edge_flow(edge_id, old_flow + inc)
            # visualization.draw_network(network)

    @staticmethod
    def __find_min_flow_in_increasing_way(network: ResidualNetwork, edges: tp.List[EdgeId]):
        return min(network.get_edge_flow(i, False) for i in edges)
